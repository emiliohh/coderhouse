class Cliente():
    def __init__(self,nombre,mail,edad,intereses):
        self.nombre = nombre
        self.mail = mail
        self.edad = edad
        self.intereses = intereses

    def comprar(self,articulo,tienda):
        self.articulo = articulo
        self.tienda = tienda
        print("El cliente ha comprado", self.articulo, "en la tienda" ,self.tienda)
        print("Se le ha mandado un coreo con su factura a", self.mail)

    def __str__(self):
        return f"Se ha creado al cliente {self.nombre}."

    def devlolver(self,articulo,marca):
        self.articulo=articulo
        self.marca=marca
        print("El cliente ha devuelto el artículo", self.articulo, "de la marca", self.marca)
