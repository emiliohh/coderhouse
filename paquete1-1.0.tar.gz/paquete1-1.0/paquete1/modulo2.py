def registro(datos={}):
  name = input("Ingrese el nombre de usuario: ")
  pswd= input("Ingrese la contraseña: ")
  datos[name] = pswd

def leerData (datos):
  print("La información almacenada en la DB es: ")
  for key, value in datos.items():
    print(f"{key} {value}")

def login(datos):
  name = input("Ingrese su usuario: ")
  if name in datos:
    pswd = input("Ingrese su contraseña: ")
    if datos[name] == pswd:
      print("Has iniciado sesión")
    else:
      print("Contraseña incorrecta")
  else:
    print("No se ha entontrado el usuario")
