from setuptools import setup

setup(
    name="paquete1",
    version="1.0",
    description="Primer paquete",
    author="Emilio Hopp",
    author_email="sin@mail.cl",
    packages=["paquete1"]
)
